package com.servlets;

import java.io.IOException;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.entities.Note;
import com.helper.FactoryProvider;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DeleteServlet")
public class DeleteServlet extends HttpServlet {
	private static final long serialVersionUID = 1000L;

	public DeleteServlet() {
		super();
	}

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		try {
			int noteId = Integer.parseInt(request.getParameter("note_id").trim()); // Trim will remove spaces from aaga
																					// and picha
			Session s = FactoryProvider.getFactory().openSession();
			Transaction tx = s.beginTransaction();
			Note note = (Note) s.get(Note.class, noteId);
			s.remove(note); // delete method is depricated from Session
			tx.commit();
			response.sendRedirect("all_notes.jsp");

			s.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

//
//package com.servlets;                                                                                         
//                                                                                                              
//import java.io.IOException;                                                                                   
//                                                                                                              
//import javax.servlet.ServletException;                                                                        
//import javax.servlet.http.HttpServlet;                                                                        
//import javax.servlet.http.HttpServletRequest;                                                                 
//import javax.servlet.http.HttpServletResponse;                                                                
//                                                                                                              
//import org.hibernate.Session;                                                                                 
//                                                                                                              
//import com.entities.Note;                                                                                     
//import com.helper.FactoryProvider;                                                                            
//                                                                                                              
//import jakarta.servlet.annotation.WebServlet;                                                                 
//                                                                                                              
//@WebServlet("/DeleteServlet")                                                                                 
//public class DeleteServlet extends HttpServlet {                                                              
//	private static final long serialVersionUID = 1000L;                                                          
//                                                                                                              
//	public DeleteServlet() {                                                                                     
//		super();                                                                                                    
//	}                                                                                                            
//                                                                                                              
//	@Override                                                                                                    
//	protected void doPost(HttpServletRequest request, HttpServletResponse response)                              
//			throws ServletException, IOException {                                                                     
//		response.setContentType("text/html");                                                                       
//		try {                                                                                                       
//			int noteId = Integer.parseInt(request.getParameter("note_id").trim()); // Trim will remove spaces from aaga
//																					// and picha                                                                             
//			Session s = FactoryProvider.getFactory().openSession();                                                    
//			Note note = (Note) s.get(Note.class, noteId);                                                              
//			s.remove(note); // delete method is depricated from Session                                                
//			response.sendRedirect("all_notes.jsp");                                                                    
//                                                                                                              
//			s.close();                                                                                                 
//                                                                                                              
//		} catch (Exception e) {                                                                                     
//			e.printStackTrace();                                                                                       
//		}                                                                                                           
//	}                                                                                                            
//                                                                                                              
//}                                                                                                             
